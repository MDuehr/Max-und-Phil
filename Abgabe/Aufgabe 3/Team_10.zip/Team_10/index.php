<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <link rel="stylesheet" type="text/css" href="html5reset-1.6.1.css">
        <link rel="stylesheet" type="text/css" href="login.css">
    </head>
    <body>
        <div id="wrapper">
            <div id="inner">
                <table>
                    <caption>Please Log In!</caption>
                    <tbody>
                        <tr>
                            <form name="loginVal" action="loginverify.php" method="post">
                            <td>Username:</td><td><input type="text" name="username"/></td>
                            <td>Password:</td><td><input type="password" name="password"/></td>
                            <td><input type="submit" name="Abschicken" value="Login"/></td>
                            </form>

                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div><a href="adminlogin.php">Login as Admin!</a></div>
        </div>
    </body>
        

</html>