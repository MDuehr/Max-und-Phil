var json = [
                  {
                    "filename": "06-BLUEMARC - BLUEMARC-BLUEMARC_-_AGA_LIFE_2012.mp3",
                    "size": "6.3 MB",
                    "type": "Audio",
                    "creation": "10.03.2013",
                    "action": "<a href='#Beispiel31'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel32'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel33'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel34'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel35'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "08-BLUEMARC - EWSKO_BLUEMARC-ROMANTIC WIND.mp3",
                    "size": "5.8 MB",
                    "type": "Audio",
                    "creation": "10.03.2013",
                    "action": "<a href='#Beispiel36'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel37'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel38'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel39'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel40'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "<img alt='amsterdam' src='media/thumbnails/amsterdam.jpg'>  amsterdam.jpg",
                    "size": "240 KB",
                    "type": "Bild",
                    "creation": "10.03.2013",
                    "action": "<a href='#Beispiel41'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel42'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel43'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel44'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel45'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "<img alt='beeren.jpg' src='media/thumbnails/beeren.jpg'/> beeren.jpg",
                    "size": "556 KB",
                    "type": "Bild",
                    "creation": "10.09.2013",
                    "action": "<a href='#Beispiel46'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel47'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel48'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel49'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel50'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "<img alt='drachen.jpg' src='media/thumbnails/drachen.jpg'/>  drachen.jpg",
                    "size": "311 KB",
                    "type": "Bild",
                    "creation": "10.09.2013",
                    "action": "<a href='#Beispiel50'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel51'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel52'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel53'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel54'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "leben.mpg",
                    "size": "426 KB",
                    "type": "Video",
                    "creation": "25.10.2014",
                    "action": "<a href='#Beispiel55'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel56'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel57'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel58'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel59'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "mimetype.txt",
                    "size": "2 KB",
                    "type": "Text",
                    "creation": "03.09.2013",
                    "action": "<a href='#Beispiel60'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel61'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel62'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel63'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel64'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "lizens_musik.txt",
                    "size": "123 Byte",
                    "type": "Text",
                    "creation": "10.09.2013",
                    "action": "<a href='#Beispiel65'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel66'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel67'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel68'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel69'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "rest_definition.txt",
                    "size": "387 Byte",
                    "type": "Text",
                    "creation": "08.09.2013",
                    "action": "<a href='#Beispiel70'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel71'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel72'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel73'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel74'><i class='fa fa-trash-o'></i></a>"
                  },
                  {
                    "filename": "readme.txt",
                    "size": "54 Byte",
                    "type": "Text",
                    "creation": "24.12.2014",
                    "action": "<a href='#Beispiel75'><i class='fa fa-eye'></i></a>" +
                                "<a href='#Beispiel76'><i class='fa fa-mail-forward'></i></a>&#124;" + 
                                "<a href='#Beispiel77'><i class='fa fa-pencil'></i></a>" +
                                "<a href='#Beispiel78'><i class='fa fa-lock'></i></a>" +
                                "<a href='#Beispiel79'><i class='fa fa-trash-o'></i></a>"
                  }
                  ];


                    var tr;
                    var trh;

                    trh = $('<tr/>');
                    trh.append("<th onclick='sortNames()'>Filename</th>");
                    trh.append("<th onclick='sortSizes()'>Size</th>");
                    trh.append("<th>Type</th>");
                    trh.append("<th>Creation</th>");
                    trh.append("<th>Actions</th>");
                    $('#parseHead').append(trh);

                    for (var i = 0; i < json.length; i++) {
                        tr = $('<tr/>');
                        tr.append("<td>" + json[i].filename + "</td>");
                        tr.append("<td>" + json[i].size + "</td>");
                        tr.append("<td>" + json[i].type + "</td>");
                        tr.append("<td>" + json[i].creation + "</td>");
                        tr.append("<td class='symboltd'>" + json[i].action + "</td>");
                        $('#parseData').append(tr);
                    }

function sortSizes(){
            json.sort(function(a,b) { return parseFloat(b.size) - parseFloat(a.size) } );

                while (document.getElementById("parseData").rows.length > 0) {
                    document.getElementById("parseData").deleteRow(0);
            }

            for (var i = 0; i < json.length; i++) {
            tr = $('<tr/>');
            tr.append("<td>" + json[i].filename + "</td>");
            tr.append("<td>" + json[i].size + "</td>");
            tr.append("<td>" + json[i].type + "</td>");
            tr.append("<td>" + json[i].creation + "</td>");
            tr.append("<td class='symboltd'>" + json[i].action + "</td>");
            $('#parseData').append(tr);
        }
    }

        function sortNames(){
            //json.sort(function(a,b) { return parseFloat(b.size) - parseFloat(a.size) } );

            json.sort(function(a, b){
                if(a.filename < b.filename) return -1;
                if(a.filename > b.filename) return 1;
                return 0;
            });

                while (document.getElementById("parseData").rows.length > 0) {
                    document.getElementById("parseData").deleteRow(0);
            } 

            for (var i = 0; i < json.length; i++) {
            tr = $('<tr/>');
            tr.append("<td>" + json[i].filename + "</td>");
            tr.append("<td>" + json[i].size + "</td>");
            tr.append("<td>" + json[i].type + "</td>");
            tr.append("<td>" + json[i].creation + "</td>");
            tr.append("<td class='symboltd'>" + json[i].action + "</td>");
            $('#parseData').append(tr);
        }
    }