
package de.mt.wme.inf_box_lib.misc;

public abstract class StaticValues {

    public static String BASE_URL = "http://wme.lehre.imld.de:8080/wme14-15/api/";
}
