
package de.mt.wme.inf_box_lib.misc;

public interface IInfboxResultHandler {

    public void handleResult(String result);

}
